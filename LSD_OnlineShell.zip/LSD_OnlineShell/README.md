team members: delia holman, shahd khourshed, lucy salyer

Execution details:
1. cd into LSD_OnlineShell
2. Run make 
3. ./server 1050
3. open new terminal
4. Run gcc client.c -o client
5. Run ./client localhost 1050
6. Run your commands! 
